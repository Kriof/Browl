import React from 'react';
import './Blog.css';

function Blog() {
    return (
        <div>
            <section className="Blog">
                <h1>Blog</h1>
            </section>
        </div>
    );
}

export default Blog;