import React from 'react';
import './Graphic.css';

function Graphic() {
    return (
        <div>
            <section className="Graphic">
                <h1>Grafika</h1>
            </section>
        </div>
    );
}

export default Graphic;