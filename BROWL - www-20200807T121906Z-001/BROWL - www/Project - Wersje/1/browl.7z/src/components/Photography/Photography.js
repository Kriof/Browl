import React from 'react';
import './Photography.css';
function Photography() {
    return (
        <div>
            <section className="Menu">
                <ul>
                    <li></li>
                </ul>
            </section>
        </div>
    );
}

export default Photography;