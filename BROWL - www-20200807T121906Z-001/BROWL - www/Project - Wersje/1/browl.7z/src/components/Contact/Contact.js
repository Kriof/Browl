import React from 'react';
import './Contact.css';

function Contact() {
    return (
        <div>
            <section className="Contact">
                <h1>Contact</h1>
            </section>
        </div>
    );
}

export default Contact;