import React from 'react';
import './LandingPage.css';
import logoBrowl from '../../images/main/logoBrowl.png'
import gwarancja from '../../images/icons/gwarancja.svg';
import jakosc from '../../images/icons/jakosc.svg';
import kontakt from '../../images/icons/kontakt.svg';
import pomysl from '../../images/icons/pomysl.svg';


function LandingPage() {
    return (
        <div>
            <section className="LandingPage">
                <div className="logo">
                    <img src={logoBrowl} />
                </div>
                <div className="text-container">
                    <h3>Cześć</h3>
                    <p>Jako zgrany zespół wykonamy projekt dostosowany do Twoich indywidualnych potrzeb.</p>
                    <p>Zapewniamy skuteczne i efektywne działania z zakresu reklamy i projektowania.</p>
                    <p>Poprowadzimy Twój fanpage w socialmediach oraz wiele, wiele innych</p>
                    <p>Zaprojektujemy dla Ciebie:</p>
                    <ul className="list">
                        <li>Logo</li>
                        <li>Materiały reklamowe</li>
                        <li>Stronę internetową</li>
                    </ul>

                </div>
                <div className="icon-section">
                    {/* <div className="icon-row"> */}
                    <div className="row">
                        <div class="column">
                            <img src={pomysl} alt="pomysl" />
                            <p>Poszukujemy kreatywnych koncepcji do konkretnego zlecenia. Indywidualnie podchodzimy do klienta i jego potrzeb</p>
                        </div>
                        <div class="column">
                            <img src={gwarancja} alt="gwarancja" />
                            <p>Gwarantujemy rzetelność i szybką obsługę. Zadbamy o wszystkie kluczowe elementy Twojego projektu.</p>
                        </div>
                    </div>


                    {/* </div>
                    <div className="icon-row"> */} 
                    <div className="row">Nie wie
                        <div class="icon">
                            <img src={jakosc} alt="jakosc" />
                            <p>Dbamy o niepowtarzalność i jakosć wykonywanej przez nas pracy.</p>
                        </div>
                        <div class="icon">
                            <img src={kontakt} alt="kontakt" />
                            <p>Zapewniamy stały kontakt z klientem podczas realizacji projektu.</p>
                        </div>
                    </div>

                    {/* </div> */}
                </div>
            </section>
        </div>
    );
}

export default LandingPage;