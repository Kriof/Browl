import React from 'react';
import './FAQ.css';

function FAQ() {
    return (
        <div>
            <section className="FAQ">
                <ul>
                    <li></li>
                </ul>
            </section>
        </div>
    );
}

export default FAQ;